---
name: Vedic Sanctum
colors:
  surface: '#fff8f6'
  surface-dim: '#f0d4cc'
  surface-bright: '#fff8f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff1ed'
  surface-container: '#ffe9e3'
  surface-container-high: '#ffe2da'
  surface-container-highest: '#f9ddd4'
  on-surface: '#271813'
  on-surface-variant: '#58413f'
  inverse-surface: '#3d2d27'
  inverse-on-surface: '#ffede8'
  outline: '#8b716e'
  outline-variant: '#dfbfbc'
  surface-tint: '#aa3530'
  primary: '#570005'
  on-primary: '#ffffff'
  primary-container: '#7b1113'
  on-primary-container: '#ff837a'
  inverse-primary: '#ffb3ac'
  secondary: '#735c00'
  on-secondary: '#ffffff'
  secondary-container: '#fed65b'
  on-secondary-container: '#745c00'
  tertiary: '#461a00'
  on-tertiary: '#ffffff'
  tertiary-container: '#692a00'
  on-tertiary-container: '#ff8741'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb3ac'
  on-primary-fixed: '#410003'
  on-primary-fixed-variant: '#891c1b'
  secondary-fixed: '#ffe088'
  secondary-fixed-dim: '#e9c349'
  on-secondary-fixed: '#241a00'
  on-secondary-fixed-variant: '#574500'
  tertiary-fixed: '#ffdbcb'
  tertiary-fixed-dim: '#ffb691'
  on-tertiary-fixed: '#341100'
  on-tertiary-fixed-variant: '#783100'
  background: '#fff8f6'
  on-background: '#271813'
  surface-variant: '#f9ddd4'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.01em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.005em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: 0em
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: 0.01em
  title-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.03em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.75rem
  margin: 1rem
  margin-md: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

This design system embodies the sanctity, reverence, and tactile richness of authentic Vedic rituals tailored for modern Nepalese and global Hindu households. It reconciles ancient traditions with modern, frictionless commerce. The aesthetic marries **Warm Editorial Classicism** with subtle **Tactile Craftsmanship**, rejecting sterile digital minimalism in favor of devotional warmth, heritage craftsmanship, and sacred architectural geometry.

### Target Audience & Emotional Tone
- **Audience:** Discerning individuals, families, and diaspora observing daily Nitya pujas, lifecycle rituals (Samskaras), and major festivals (Dashain, Tihar, Shivaratri) who prioritize untainted ritual purity (Suddha Samagri), certified brass metallurgy, and traditional provenance.
- **Emotional Response:** Reverence, spiritual peace, absolute trust in purity, warmth, and grounded auspiciousness. The app should feel less like a clinical warehouse and more like stepping into a peaceful, brass-lit sanctum filled with the scent of sandalwood and freshly plucked marigolds.

### Aesthetic Foundation
- **Devotional Tactility:** Surfaces reference warm handmade Lokta paper, soft raw silk, and unglazed earthen terracotta. Cards rely on delicate hairline borders reminiscent of temple brass repoussé rather than heavy modern drop shadows.
- **Subtle Sacred Geometry:** Borders incorporate delicate traditional Nepalese and Vedic architectural motifs—subtle lotus-petal corner framing, hairline mandala accents, and auspicious stepped geometric dividers.

## Colors

The color palette draws directly from the sacred substances of ritual Hindu worship (Kumkum, Chandan, Kesar, and Brass). Stark cool grays and pure cold whites (#FFFFFF) are strictly avoided for overarching page surfaces to maintain organic, temple-grade warmth.

### Roles & Harmonies
- **Primary — Deep Sindoor Maroon (`#7B1113` / `#8B1E1E`):** Represents spiritual devotion, Shakti, and sanctification. Used for high-impact brand moments, app headers, primary structural emphasis, devotional status badges, and critical price headings.
- **Secondary / Accent — Temple Brass Gold (`#D4AF37` / `#C59B27`):** Evokes the glow of Panchadhatu, beaten brass puja thalis, and polished diyas. Applied to card borders, sacred verification crests, active states, step connectors, and ornamental trims.
- **Tertiary / Action — Sacred Marigold Orange (`#EA6A10` / `#FF9933`):** Reflects the radiant fire of Havana (Agni) and festive marigold malas. Used intentionally for high-conversion calls to action ("Add to Thali", "Book Muhurat Dispatch"), flash announcements, and celebratory urgency tags.
- **Neutral & Typography — Deep Charcoal Warm Brown (`#2A1B16`) & Muted Umber (`#695A52`):** Grounded earth tones derived from dried sandalwood and aged sal timber. Delivers high-contrast legibility without the harsh dissonance of pitch black.
- **Surfaces & Canvases — Sandalwood Cream (`#FBF8F2`) & Ivory Silk (`#FFFDF9`):** Provides a warm, comforting base canvas reminiscent of sacred handmade paper and unbleached altar linen.

## Typography

The typographic hierarchy establishes clear editorial balance: **Playfair Display** introduces cultural grandeur, ritual significance, and devotional reverence for sacred names, deity titles, and major collection headings. **Plus Jakarta Sans** provides modern, high-clarity legibility for practical transactional details—such as item lists, ritual procedures, Nepali Rupee figures (`रू / NPR`), and Vedic weight specifications (Tola, Grams, Liters).

### Implementation Rules
- **Ritual Titles & Samagri Headers:** Always rendered in Playfair Display to maintain a crafted, scriptural presence.
- **Transactional & Quantitative Data:** Currency notations (`रू 2,450`), weight measurements, Vedic origin tags, and checklists must always use Plus Jakarta Sans to prevent legibility issues during checkout and packing verification.
- **Letter Spacing:** All uppercase label badges ("VEDIC PURITY CERTIFIED", "SHUBHA MUHURAT") use expanded letter spacing (0.05em) for crisp architectural precision.

## Layout & Spacing

This design system is engineered primarily for mobile touchscreens, with clean adaptation to tablet and desktop screens. It employs a fluid 4-column layout on mobile devices with consistent 16px (`1rem`) outer margins and gutters.

### Rhythm & Proportions
- **Visual Breathing Room:** Content density mirrors the serene cadence of a temple mandir rather than high-anxiety flash sales. Generous vertical padding separates distinct puja segments.
- **Rhythm Multiples:** Spacing stems from a baseline 4px/8px modular rhythm. Tight component associations (e.g., samagri count badge and item name) utilize `space-xs` (4px) or `space-sm` (8px), while ritual collections and product pairings utilize `space-lg` (20px) to `space-xl` (32px).
- **Responsive Adaptations:**
  - **Mobile (<600px):** 4-column fluid layout, edge margin `1rem`, compact vertical spacing.
  - **Tablet (600px–1024px):** 8-column layout, margin `1.5rem`, expanded visual cards for ceremonial bundles.
  - **Desktop (>1024px):** 12-column bounded canvas (max 1200px) with generous lateral margins.

## Elevation & Depth

Visual hierarchy abandons heavy synthetic drop shadows. Instead, it utilizes **Tonal Layers** accented by **Warm Brass Hairline Boundaries** and soft, amber-tinted ambient glows that simulate lamplight from brass diyas.

### Tonal Hierarchy
- **Canvas (Ground):** Sandalwood Cream (`#FBF8F2`) serves as the base surface.
- **Surface Level 1 (Cards & Modules):** Warm Ivory Silk (`#FFFDF9`) bounded by a subtle 1px border of Pale Brass (`#D4AF37` at 28% opacity).
- **Surface Level 2 (Floating Action Sheets & Modals):** Pure Altar White (`#FFFFFF`) with a 1px border of Solid Brass (`#C59B27`) paired with a diffused ambient shadow: `box-shadow: 0 10px 25px -5px rgba(123, 17, 19, 0.08), 0 4px 6px -2px rgba(212, 175, 55, 0.12)`.
- **Sacred Focal Glow:** Selected puja kits, active auspicious muhurat selectors, and certified purity marks cast a warm golden perimeter halo: `box-shadow: 0 0 12px 1px rgba(212, 175, 55, 0.22)`.

## Shapes

The design system employs a **Soft** shape archetype (`roundedness: 1`). Radii are kept modest and structured (4px base, 8px for cards and sheets, 12px for primary imagery), evoking classic architectural niches, traditional wood carvings, and brass-etched plates. 

Circular shapes are reserved exclusively for sacred icons, Diya/Kalash indicators, avatar seals, and stamp-like Vedic authenticity seals. Highly rounded "pill" forms are restricted to status badges to maintain a clean distinction between interactive actions and structural containers.

## Components

### Buttons
- **Primary Festive Action ("Add Thali to Cart", "Book Muhurat"):** Solid Saffron Marigold (`#EA6A10`) background, crisp white typography in Plus Jakarta Sans SemiBold. Subtle 1px inner border highlight (`rgba(255,255,255,0.2)`), corner radius 8px (`0.5rem`).
- **Secondary Devotional Action ("Inspect Samagri List", "View Vidhi"):** Deep Sindoor Maroon (`#7B1113`) background with 1px Temple Brass border (`#D4AF37`) and gold text.
- **Tertiary / Outlined:** Transparent background with 1px border in Temple Brass Gold (`#C59B27`), text in Deep Charcoal Warm Brown (`#2A1B16`).

### Cards & Product Displays
- **Puja Kit Card:** Ivory Silk (`#FFFDF9`) background, 1px perimeter border in Pale Brass (`rgba(212, 175, 55, 0.35)`), corner radius 8px. Images feature a subtle inset gold hairline frame. Price displays prominent NPR (`रू`) notation in bold sans-serif alongside a Sanskrit/Nepali subtitle in delicate Playfair Display.
- **Temple Artifact Cards (Brass & Copper Thalis):** Hero product imagery grounded with a soft circular aura reminiscent of oil lamplight (`radial-gradient(circle, rgba(212, 175, 55, 0.15) 0%, transparent 70%)`).

### Chips & Filter Pills
- **Unselected:** Sandalwood Cream background, 1px border in warm umber tint (`#E5DDD5`), text in `#695A52`.
- **Selected (Active Deity/Festival filter):** Deep Sindoor Maroon (`#7B1113`) background with golden text (`#FBF8F2`) and 1px border in `#D4AF37`.

### Lists & Checklists (Vedic Samagri Checklist)
- Ritual sets require itemized purity inspection. Checklist items feature custom brass-toned checkboxes (`#D4AF37`) with dark Sindoor checkmarks.
- Each list row includes quantity, certified origin (e.g., "Mustard Oil from Chitwan", "Supari from Biratnagar", "Pure Rato Sindoor"), and an expandable modal for purity credentials.

### Badges & Authentic Crests
- **Vedic Purity Guarantee:** Circular or notched-corner banner featuring a Kalash or Diya motif in gold metallic gradient, encircled by a 1px brass stroke and uppercase typography ("100% S蘭DDHA CERTIFIED").
- **Muhurat Timestamp:** Soft amber pill (`rgba(234, 106, 16, 0.12)`) with Marigold text and a gentle flame icon indicating auspicious dispatch windows.

### Form Inputs & Selectors
- Form elements (address, priest contact, sankalpa details) feature Ivory Silk surfaces, 1px borders in `#D9CFC4`, turning to polished Temple Brass (`#C59B27`) on active focus with an ambient amber glow. Helper texts sit in muted umber (`#695A52`).